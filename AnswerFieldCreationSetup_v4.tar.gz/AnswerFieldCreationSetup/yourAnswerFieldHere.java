//see http://www.ingatan.org/wiki/AnswerFieldsTutorial for a tutorial.
//this is AnswerFieldCreationSetup v4.

import org.ingatan.component.answerfield.IAnswerField;

public class yourAnswerFieldHere implements IAnswerField extends JComponent {
    /**
     * Whether or not the answer field is in the edit or quiz context. Set
     * when the answer field is instantiated.
     */
    private boolean isInEditContext = true;

    public String getDisplayName() {
        return "";
    }
    
    public boolean isOnlyForAnswerArea() {
        //return false if you want to be able to insert your answer
        //field into the question and post-answer text areas too.
        return true;
    }
    
    public void setContext(boolean inEditContext) {
        this.isInEditContext = inEditContext;
    }
    
    public String getParentLibraryID() {
        //only implement if your answer field uses resources/images
        return "";
    }

    public void setParentLibraryID(String id) {
        //only implement if your answer field uses resources/images
    }
    
    public void setQuizContinueListener() {
        
    }
    
    public int getMaxMarks() {
        return 0;
    }

    public float checkAnswer() {
        return 0.0f;
    }

    public int getMarksAwarded() {
        return (int) (getMaxMarks() * checkAnswer());
    }

    public void displayCorrectAnswer() {
    
    }
    
    public void resaveImagesAndResources(String newLibraryID) {
        //only implement if your answer field uses resources/images
    }

    public String writeToXML() {
        return "";
    }

    public void readInXML(String xml) {
    }

}
